
import React from 'react';
import { Hero } from './components/Hero';
import { About } from './components/About';
import { Experience } from './components/Experience';
import { Socials } from './components/Socials';
import { Footer } from './components/Footer';
import { Navbar } from './components/Navbar';
import { CustomCursor } from './components/CustomCursor';

const App: React.FC = () => {
  return (
    <div className="relative min-h-screen bg-[#020202] text-white selection:bg-white selection:text-black overflow-x-hidden font-sans">
      <CustomCursor />
      
      {/* Boxed Layout Container */}
      <div className="relative max-w-[1440px] mx-auto bg-[#070707] min-h-screen border-x border-white/5 shadow-2xl flex flex-col">
        {/* Navbar is sticky top-0, so it must be first inside this container */}
        <Navbar />
        
        <main className="flex-grow">
          <Hero />
          <About />
          <Experience />
          <Socials />
        </main>

        <Footer />
      </div>
      
      {/* Background Subtle Elements - Fixed to viewport */}
      <div className="fixed inset-0 pointer-events-none z-0 opacity-10">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-blue-500/10 blur-[120px] rounded-full"></div>
        <div className="absolute bottom-[10%] right-[-5%] w-[30%] h-[30%] bg-purple-500/10 blur-[100px] rounded-full"></div>
      </div>
    </div>
  );
};

export default App;
