import React from 'react';
import { motion, Variants } from 'framer-motion';

const containerVariants: Variants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
      delayChildren: 0.3,
    },
  },
};

const textVariants: Variants = {
  hidden: { y: 20, opacity: 0 },
  visible: {
    y: 0,
    opacity: 1,
    transition: { duration: 0.8, ease: "easeOut" },
  },
};

export const About: React.FC = () => {
  return (
    <section id="about" className="py-32 px-8 md:px-20 lg:px-32 bg-[#0a0a0a]">
      <div className="max-w-4xl mx-auto">
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          variants={containerVariants}
        >
          <motion.h2 variants={textVariants} className="font-heading text-4xl md:text-5xl font-bold mb-12 uppercase tracking-tighter text-white">
            THE VISION.
          </motion.h2>
          
          <motion.p variants={textVariants} className="font-body text-xl md:text-3xl leading-relaxed text-white font-light">
            Hi, I'm <span className="text-white font-bold underline decoration-white/30 underline-offset-8">Rakib Howladar</span>, a Web Developer and AI Automation Engineer. 
            I build modern websites and automate workflows using 
            <span className="text-white font-bold italic"> advanced automation platforms</span> to make processes smarter 
            and more efficient.
          </motion.p>
          
          <motion.div variants={textVariants} className="mt-12 h-[1px] w-full bg-white/20"></motion.div>
          
          <motion.p variants={textVariants} className="mt-12 font-body text-lg md:text-xl text-slate-100 font-light leading-relaxed max-w-2xl">
            My approach blends aesthetics with functionality. Every line of code is written to serve a purpose, and every automation is designed to save time, allowing human creativity to flourish through optimized digital environments.
          </motion.p>
        </motion.div>
      </div>
    </section>
  );
};