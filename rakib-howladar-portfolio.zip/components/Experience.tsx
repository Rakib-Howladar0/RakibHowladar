import React from 'react';
import { motion } from 'framer-motion';
import { Star } from 'lucide-react';

const experiences = [
  {
    title: "Web Designer",
    desc: "Creating modern, responsive designs. Crafting visually appealing and user-friendly websites.",
    status: "Mastered"
  },
  {
    title: "AI Automation",
    desc: "Exploring workflow automation with modern industry-standard tools to make processes smarter and more efficient.",
    status: "Ongoing"
  },
  {
    title: "Personal Growth",
    desc: "Continuously expanding skills and combining web design with automation for smarter solutions.",
    status: "Advanced"
  }
];

export const Experience: React.FC = () => {
  return (
    <section id="experience" className="relative py-32 px-8 md:px-20 lg:px-32 overflow-hidden">
      {/* Background Soft Glows */}
      <div className="absolute top-1/4 -left-20 w-[400px] h-[400px] bg-white/[0.03] blur-[100px] rounded-full pointer-events-none z-0"></div>
      <div className="absolute bottom-1/4 -right-20 w-[400px] h-[400px] bg-white/[0.03] blur-[100px] rounded-full pointer-events-none z-0"></div>
      
      {/* Left Floating Sparkle */}
      <motion.div 
        className="absolute left-[5%] top-1/2 -translate-y-1/2 z-0 opacity-10 pointer-events-none hidden lg:block"
        animate={{ 
          y: ["-40%", "-60%", "-40%"],
          rotate: [0, 45, 0],
          opacity: [0.05, 0.15, 0.05]
        }}
        transition={{ duration: 10, repeat: Infinity, ease: "easeInOut" }}
      >
        <Star size={180} strokeWidth={0.5} className="text-white" />
      </motion.div>

      {/* Right Floating Sparkle */}
      <motion.div 
        className="absolute right-[5%] top-1/2 -translate-y-1/2 z-0 opacity-10 pointer-events-none hidden lg:block"
        animate={{ 
          y: ["-60%", "-40%", "-60%"],
          rotate: [0, -45, 0],
          opacity: [0.05, 0.15, 0.05]
        }}
        transition={{ duration: 12, repeat: Infinity, ease: "easeInOut", delay: 1 }}
      >
        <Star size={180} strokeWidth={0.5} className="text-white" />
      </motion.div>

      <div className="max-w-6xl mx-auto relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-24"
        >
          <span className="font-heading text-[10px] md:text-xs tracking-[0.6em] uppercase font-black text-white/30 mb-4 block">
            MY EVOLUTION
          </span>
          <h2 className="font-heading text-4xl md:text-7xl font-bold uppercase tracking-tighter text-white">
            GROWTH & JOURNEY.
          </h2>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
          {experiences.map((exp, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.2, duration: 0.8 }}
              whileHover={{ y: -10 }}
              className="group relative p-10 bg-white/[0.02] border border-white/10 hover:border-white/30 transition-all duration-500 rounded-[3rem] backdrop-blur-sm overflow-hidden"
            >
              {/* Card Sparkle Accent */}
              <div className="absolute top-8 right-8 opacity-0 group-hover:opacity-100 transition-opacity duration-500">
                <Star size={16} className="text-white animate-pulse" fill="white" />
              </div>

              <div className="mb-8 flex justify-between items-center">
                <div className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center border border-white/10">
                  <span className="font-heading font-black text-xs text-white/60">0{index + 1}</span>
                </div>
                <span className="text-[10px] font-heading font-black uppercase tracking-widest bg-white/5 border border-white/20 px-4 py-1.5 rounded-full text-white/70 group-hover:bg-white group-hover:text-black transition-all duration-500 shadow-xl">
                  {exp.status}
                </span>
              </div>

              <h3 className="font-heading text-2xl md:text-3xl font-bold mb-5 text-white tracking-tight">
                {exp.title}
              </h3>
              
              <p className="font-body text-white/60 font-light leading-relaxed text-sm md:text-base group-hover:text-white/90 transition-colors duration-500">
                {exp.desc}
              </p>

              {/* Decorative corner curve */}
              <div className="absolute -bottom-10 -right-10 w-24 h-24 bg-white/5 blur-3xl rounded-full transition-all duration-500 group-hover:bg-white/10"></div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};