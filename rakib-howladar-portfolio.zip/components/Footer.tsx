import React from 'react';
import { motion } from 'framer-motion';

export const Footer: React.FC = () => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="relative py-20 px-8 md:px-20 lg:px-32 bg-[#050505] border-t border-white/10 overflow-hidden">
      {/* Background Subtle Luxury Element - Slightly more visible */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 opacity-[0.03] font-heading font-black text-[22vw] leading-none pointer-events-none select-none tracking-tighter text-white">
        CONTACT
      </div>

      <div className="max-w-5xl mx-auto flex flex-col items-center text-center relative z-10">
        {/* Large Animated Email Section */}
        <motion.div 
          className="mb-16 w-full"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 1, ease: [0.16, 1, 0.3, 1] }}
        >
          <span className="font-heading text-[11px] md:text-xs tracking-[0.4em] uppercase font-bold text-white/50 mb-6 block">
            ESTABLISHED INQUIRIES
          </span>
          <motion.a 
            href="mailto:mdrakib28426@gmail.com"
            className="group relative inline-block font-heading text-4xl md:text-6xl lg:text-7xl font-black tracking-tighter transition-all duration-700"
            animate={{ 
              y: [0, -5, 0],
            }}
            transition={{ 
              duration: 5, 
              repeat: Infinity, 
              ease: "easeInOut" 
            }}
          >
            <span className="relative z-10 bg-gradient-to-b from-white via-slate-100 to-white/60 bg-clip-text text-transparent animate-gradient-flow bg-[length:200%_200%]">
              mdrakib28426@gmail.com
            </span>
            
            {/* Animated Precision Line */}
            <span className="absolute -bottom-4 left-1/2 -translate-x-1/2 w-16 h-[2px] bg-white transition-all duration-700 group-hover:w-full opacity-40"></span>
            
            {/* Hover Glow Effect */}
            <div className="absolute inset-0 blur-[60px] bg-white/10 opacity-0 group-hover:opacity-100 transition-opacity duration-1000 -z-10"></div>
          </motion.a>
        </motion.div>

        {/* Improved Back to Top Button - Ultra-Modern Luxury */}
        <div className="relative mb-16 group">
          <motion.button 
            onClick={scrollToTop}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="relative w-20 h-20 rounded-full border border-white/20 flex items-center justify-center transition-all duration-500 z-20 overflow-hidden bg-white/5 hover:bg-white"
          >
            <svg 
              width="24" 
              height="24" 
              viewBox="0 0 24 24" 
              fill="none" 
              stroke="currentColor" 
              strokeWidth="1.5" 
              strokeLinecap="round" 
              strokeLinejoin="round"
              className="relative z-10 text-white group-hover:text-black group-hover:-translate-y-1 transition-all duration-500"
            >
              <path d="M12 19V5M5 12l7-7 7 7"/>
            </svg>
          </motion.button>
          
          {/* Decorative Minimal Rings */}
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-28 h-28 rounded-full border border-white/10 group-hover:border-white/20 transition-colors duration-500 pointer-events-none"></div>
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-36 h-36 rounded-full border border-white/[0.03] pointer-events-none"></div>
        </div>

        {/* Content Section - Clear Visibility */}
        <div className="flex flex-col gap-6 w-full">
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="flex flex-col items-center"
          >
            <p className="font-heading text-lg md:text-2xl font-light tracking-tight text-white">
              Designed & Developed by <span className="font-bold underline decoration-white/20 underline-offset-4">Rakib Howladar</span>.
            </p>
          </motion.div>

          <div className="w-full max-w-xs h-[1px] bg-gradient-to-r from-transparent via-white/20 to-transparent mx-auto"></div>

          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.3, duration: 0.8 }}
          >
            <p className="font-heading text-[10px] md:text-[12px] tracking-[0.5em] uppercase font-bold text-white/40">
              © 2026 Rakib Howladar. All Rights Reserved.
            </p>
          </motion.div>
        </div>

        {/* Minimalist Tech Signature */}
        <div className="mt-16 flex items-center justify-center gap-6 text-white/40">
          <span className="text-[9px] tracking-[0.3em] font-bold uppercase">BANGLADESH</span>
          <div className="w-1 h-1 rounded-full bg-white/20"></div>
          <span className="text-[9px] tracking-[0.3em] font-bold uppercase">AVAILABLE</span>
          <div className="w-1 h-1 rounded-full bg-white/20"></div>
          <span className="text-[9px] tracking-[0.3em] font-bold uppercase italic">FOR HIRE</span>
        </div>
      </div>

      <style>{`
        @keyframes gradient-flow {
          0% { background-position: 50% 0%; }
          50% { background-position: 50% 100%; }
          100% { background-position: 50% 0%; }
        }
        .animate-gradient-flow {
          background-image: linear-gradient(to bottom, #ffffff, #cbd5e1, #ffffff, #64748b);
          background-size: 100% 400%;
          animation: gradient-flow 10s ease infinite;
        }
      `}</style>
    </footer>
  );
};