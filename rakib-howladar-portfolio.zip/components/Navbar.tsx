import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Menu, X } from 'lucide-react';

export const Navbar: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'About', href: '#' },
    { name: 'Experience', href: '#' },
    { name: 'Contact', href: '#' },
  ];

  const handleLinkClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    if (href === '#') {
      e.preventDefault();
    }
    setIsMobileMenuOpen(false);
  };

  return (
    <>
      <nav 
        className={`fixed top-0 left-0 right-0 z-[100] transition-all duration-700 ease-in-out px-6 md:px-12 py-6 ${
          isScrolled ? 'translate-y-2' : 'translate-y-0'
        }`}
      >
        <div 
          className={`max-w-6xl mx-auto flex justify-between items-center transition-all duration-500 rounded-full px-8 py-3 ${
            isScrolled 
              ? 'bg-white/5 backdrop-blur-xl border border-white/10 shadow-[0_8px_32px_rgba(0,0,0,0.5)]' 
              : 'bg-transparent'
          }`}
        >
          {/* Logo - Elegant & Minimal */}
          <motion.a 
            href="#" 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="flex items-center group"
          >
            <span className="text-2xl font-heading font-black tracking-[-0.08em] uppercase text-white group-hover:tracking-[0.1em] transition-all duration-500 ease-in-out">
              RAKIB<span className="text-white/30 group-hover:text-white transition-colors">.</span>
            </span>
          </motion.a>

          {/* Desktop Links - Refined Spacing */}
          <div className="hidden md:flex items-center space-x-10">
            {navLinks.map((link, i) => (
              <motion.a 
                key={link.name}
                href={link.href}
                onClick={(e) => handleLinkClick(e, link.href)}
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                className="relative font-heading text-[11px] tracking-[0.3em] uppercase text-white/50 hover:text-white transition-colors duration-500 group"
              >
                {link.name}
                <span className="absolute -bottom-1 left-1/2 w-0 h-[1px] bg-white transition-all duration-500 -translate-x-1/2 group-hover:w-full opacity-0 group-hover:opacity-100" />
              </motion.a>
            ))}
            <motion.a 
              href="https://wa.me/8801732828426"
              target="_blank"
              rel="noopener noreferrer"
              className="bg-white text-black px-6 py-2 rounded-full font-heading text-[10px] font-black uppercase tracking-widest hover:bg-transparent hover:text-white border border-white transition-all duration-500"
            >
              Let's Talk
            </motion.a>
          </div>

          {/* Mobile Toggle */}
          <button 
            className="md:hidden text-white w-10 h-10 flex items-center justify-center rounded-full bg-white/5 border border-white/10"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            {isMobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
      </nav>

      {/* Luxury Fullscreen Mobile Menu */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, backdropFilter: "blur(0px)" }}
            animate={{ opacity: 1, backdropFilter: "blur(40px)" }}
            exit={{ opacity: 0, backdropFilter: "blur(0px)" }}
            className="fixed inset-0 z-[90] bg-black/90 flex flex-col justify-center items-center"
          >
            <div className="flex flex-col items-center space-y-12">
              {navLinks.map((link, i) => (
                <motion.a 
                  key={link.name}
                  href={link.href}
                  onClick={(e) => handleLinkClick(e, link.href)}
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.1 }}
                  className="font-heading text-6xl font-black uppercase tracking-tighter hover:italic hover:pl-8 transition-all duration-500"
                >
                  {link.name}
                </motion.a>
              ))}
              <motion.a 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.4 }}
                href="https://wa.me/8801732828426"
                target="_blank"
                rel="noopener noreferrer"
                className="text-white/50 font-heading tracking-[0.3em] uppercase text-sm mt-12 hover:text-white transition-colors"
              >
                Contact via WhatsApp
              </motion.a>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};