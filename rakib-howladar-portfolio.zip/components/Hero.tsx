import React from 'react';
import { motion } from 'framer-motion';

export const Hero: React.FC = () => {
  return (
    <section className="relative min-h-[95vh] flex flex-col justify-center px-6 md:px-20 lg:px-24 z-10 overflow-hidden pt-32 pb-20">
      <div className="max-w-7xl mx-auto w-full grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
        
        {/* Text Content */}
        <div className="lg:col-span-7">
          <motion.div 
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.2, ease: "easeOut" }}
            className="mb-8"
          >
            <div className="font-heading font-medium text-sm md:text-base uppercase tracking-[0.4em] text-white flex items-center gap-4">
              <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse"></span>
              READY TO BUILD THE NEXT BIG THING
            </div>
            <p className="font-heading text-[10px] md:text-xs uppercase tracking-[0.2em] text-slate-200 mt-2 ml-6">
              Open to collaborations and new challenges.
            </p>
          </motion.div>
          
          <motion.h1 
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 1, delay: 0.4, ease: [0.16, 1, 0.3, 1] }}
            className="font-heading text-6xl md:text-8xl lg:text-[9.5rem] leading-[0.82] mb-12 tracking-[-0.04em] font-black uppercase text-white"
          >
            RAKIB <br /> 
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-white via-white to-slate-400">
              HOWLADAR
            </span>
          </motion.h1>

          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1, delay: 1 }}
            className="flex flex-col md:flex-row md:items-center space-y-6 md:space-y-0 md:space-x-16 mt-16"
          >
            <div className="flex items-center space-x-4">
              <span className="w-12 md:w-16 h-[2px] bg-white opacity-100"></span>
              <span className="text-xs md:text-sm font-heading uppercase tracking-[0.3em] font-bold text-white">Web Developer</span>
            </div>
            <div className="flex items-center space-x-4">
              <span className="w-12 md:w-16 h-[2px] bg-white opacity-100"></span>
              <span className="text-xs md:text-sm font-heading uppercase tracking-[0.3em] font-bold text-white">AI Automation Enthusiast</span>
            </div>
          </motion.div>
        </div>

        {/* Premium Portrait Section */}
        <motion.div 
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1.2, delay: 0.6, ease: "easeOut" }}
          className="lg:col-span-5 flex justify-center lg:justify-end"
        >
          <div className="relative group">
            {/* Outer Luxury Frame Decoration */}
            <div className="absolute -inset-8 border border-white/20 scale-95 group-hover:scale-100 group-hover:border-white/40 transition-all duration-700 pointer-events-none rounded-3xl"></div>
            <div className="absolute -inset-px bg-gradient-to-tr from-white/30 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-1000 pointer-events-none rounded-3xl"></div>
            
            {/* Main Image Container */}
            <motion.div
              className="relative w-72 h-96 md:w-[420px] md:h-[580px] overflow-hidden grayscale-0 bg-[#111] transition-all duration-1000 ease-in-out border border-white/20 shadow-[0_0_50px_rgba(255,255,255,0.05)] rounded-3xl"
              animate={{
                y: [0, -25, 0],
              }}
              transition={{
                duration: 8,
                repeat: Infinity,
                ease: "easeInOut",
              }}
            >
              <motion.img 
                src="https://i.postimg.cc/K81TqVZj/Rakib-howladar.png" 
                alt="Rakib Howladar"
                className="w-full h-full object-cover object-top"
                initial={{ filter: "blur(2px)", opacity: 0.95, scale: 1.05 }}
                whileHover={{ 
                  filter: "blur(0px)", 
                  opacity: 1, 
                  scale: 1.02,
                  transition: { duration: 0.5, ease: "easeOut" }
                }}
                transition={{ duration: 1 }}
              />
              
              {/* Subtle Vignette Overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-black/10 pointer-events-none"></div>
              
              {/* Subtle Scanning Light Effect */}
              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-[2500ms] ease-in-out"></div>

              {/* Floating Label - Inside the animated container */}
              <motion.div 
                className="absolute bottom-6 right-6 bg-white py-3 px-6 shadow-2xl z-20 rounded-full"
                whileHover={{ scale: 1.1, rotate: -2 }}
                transition={{ type: "spring", stiffness: 400 }}
              >
                <span className="text-black font-heading font-black text-xs md:text-sm uppercase tracking-[0.3em] italic">
                  RAKIB
                </span>
              </motion.div>
            </motion.div>
          </div>
        </motion.div>

      </div>

      <motion.div 
        animate={{ y: [0, 15, 0] }}
        transition={{ repeat: Infinity, duration: 2.5 }}
        className="absolute bottom-12 left-1/2 -translate-x-1/2 opacity-60 hidden md:block"
      >
        <div className="w-[2px] h-20 bg-gradient-to-b from-white via-white to-transparent"></div>
      </motion.div>
    </section>
  );
};