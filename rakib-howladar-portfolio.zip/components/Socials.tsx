import React from 'react';
import { motion } from 'framer-motion';
import { Facebook, Linkedin, MessageCircle, ArrowUpRight } from 'lucide-react';

// Custom high-quality Behance icon SVG
const BehanceIcon = ({ size = 48 }: { size?: number }) => (
  <svg 
    width={size} 
    height={size} 
    viewBox="0 0 24 24" 
    fill="none" 
    stroke="currentColor" 
    strokeWidth="1.5" 
    strokeLinecap="round" 
    strokeLinejoin="round"
  >
    <path d="M9 12h-4.5" />
    <path d="M9 15h-4.5" />
    <path d="M12.5 15.5c0 1.381-1.119 2.5-2.5 2.5h-5.5v-10h5.5c1.381 0 2.5 1.119 2.5 2.5v1c0 1.105-.895 2-2 2 1.105 0 2 .895 2 2v2z" />
    <path d="M15 14h6" />
    <path d="M15 11c0-1.105 1.343-2 3-2s3 .895 3 2" />
  </svg>
);

const socialLinks = [
  {
    name: "Facebook",
    icon: <Facebook size={56} />,
    url: "https://www.facebook.com/rakibhowlader12",
    brandColor: "#1877F2"
  },
  {
    name: "LinkedIn",
    icon: <Linkedin size={56} />,
    url: "https://www.linkedin.com/in/rakib-howladar-6b396b329/",
    brandColor: "#0077B5"
  },
  {
    name: "Behance",
    icon: <BehanceIcon size={56} />,
    url: "https://www.behance.net/rakib-howlader",
    brandColor: "#0057ff"
  },
  {
    name: "WhatsApp",
    icon: <MessageCircle size={56} />,
    url: "https://wa.me/8801732828426",
    brandColor: "#25D366"
  }
];

export const Socials: React.FC = () => {
  return (
    <section id="contact" className="py-32 px-8 md:px-20 lg:px-32 bg-[#0a0a0a]">
      <div className="max-w-6xl mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-end mb-24 gap-8">
          <div>
            <motion.h2 
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="font-heading text-4xl md:text-7xl font-bold uppercase tracking-tighter"
            >
              Let's build <br /> something great.
            </motion.h2>
          </div>
          <motion.div 
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 1, ease: "easeOut" }}
            className="font-heading text-sm tracking-[0.2em] text-slate-400 flex flex-col items-start md:items-end gap-1"
          >
            <div className="flex items-center gap-3">
              <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span>
              READY TO BUILD THE NEXT BIG THING
            </div>
            <span className="text-[10px] text-slate-500 uppercase tracking-widest font-bold">Open to collaborations and new challenges.</span>
          </motion.div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {socialLinks.map((link, index) => (
            <motion.a
              key={index}
              href={link.url}
              target="_blank"
              rel="noopener noreferrer"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="group relative h-48 md:h-64 flex flex-col justify-center items-center bg-white/[0.03] border border-white/10 rounded-[2.5rem] transition-all duration-500 overflow-hidden hover:bg-white/[0.07] hover:border-white/20 shadow-2xl"
              style={{ '--brand-color': link.brandColor } as React.CSSProperties}
            >
              <motion.div 
                className="z-10 text-white transition-all duration-300 ease-in-out group-hover:text-[var(--brand-color)]"
                animate={{ 
                  y: [0, -10, 0],
                  scale: [1, 1.05, 1],
                  opacity: [0.8, 1, 0.8]
                }}
                transition={{ 
                  duration: 4, 
                  repeat: Infinity, 
                  ease: "easeInOut",
                  delay: index * 0.5
                }}
                whileHover={{ 
                  scale: 1.2, 
                  rotate: 5,
                  filter: `drop-shadow(0 0 25px ${link.brandColor}66)`
                }}
              >
                {link.icon}
              </motion.div>
              
              <span className="absolute bottom-8 font-heading text-xs font-bold uppercase tracking-[0.3em] text-slate-500 group-hover:text-white transition-colors duration-300">
                {link.name}
              </span>
              
              <div className="absolute inset-0 bg-[var(--brand-color)] opacity-0 group-hover:opacity-[0.05] transition-opacity duration-500" />
              
              <div className="absolute top-8 right-8 opacity-0 group-hover:opacity-100 transition-all duration-500 translate-x-2 -translate-y-2 group-hover:translate-x-0 group-hover:translate-y-0">
                <ArrowUpRight size={24} className="text-white" />
              </div>

              <div className="absolute -inset-full bg-gradient-to-r from-transparent via-white/5 to-transparent skew-x-12 -translate-x-full group-hover:animate-[sweep_1.5s_ease-in-out_infinite] pointer-events-none" />
            </motion.a>
          ))}
        </div>
      </div>
      <style>{`
        @keyframes sweep {
          0% { transform: translateX(-100%) skewX(-15deg); }
          100% { transform: translateX(200%) skewX(-15deg); }
        }
      `}</style>
    </section>
  );
};